package reto02;

public class reto2 {

    static class Nodo {

        int dato;
        Nodo siguiente;

        public Nodo(int dato) {
            this.dato = dato;
            this.siguiente = null;
        }
    }

    static class ListaEnlazada {

        private Nodo cabeza;

        public ListaEnlazada() {
            this.cabeza = null;
        }

        public void eliminarRepetidos() {
            Nodo dummy = new Nodo(-1);
            dummy.siguiente = cabeza;
            Nodo actual = dummy;

            while (actual.siguiente != null && actual.siguiente.siguiente != null) {
                if (actual.siguiente.dato == actual.siguiente.siguiente.dato) {
                    int duplicado = actual.siguiente.dato;
                    while (actual.siguiente != null && actual.siguiente.dato == duplicado) {
                        actual.siguiente = actual.siguiente.siguiente;
                    }
                } else {
                    actual = actual.siguiente;
                }
            }
            cabeza = dummy.siguiente;
        }

        public void eliminarRepetidosSinDummy() {
            while (cabeza != null && cabeza.siguiente != null && cabeza.dato == cabeza.siguiente.dato) {
                int duplicado = cabeza.dato;
                while (cabeza != null && cabeza.dato == duplicado) {
                    cabeza = cabeza.siguiente;
                }
            }

            if (cabeza == null) {
                return;
            }

            Nodo actual = cabeza;
            while (actual.siguiente != null && actual.siguiente.siguiente != null) {
                if (actual.siguiente.dato == actual.siguiente.siguiente.dato) {
                    int duplicado = actual.siguiente.dato;
                    while (actual.siguiente != null && actual.siguiente.dato == duplicado) {
                        actual.siguiente = actual.siguiente.siguiente;
                    }
                } else {
                    actual = actual.siguiente;
                }
            }
        }

        public void insertarFinal(int dato) {
            Nodo nuevoNodo = new Nodo(dato);
            if (cabeza == null) {
                cabeza = nuevoNodo;
                return;
            }
            Nodo actual = cabeza;
            while (actual.siguiente != null) {
                actual = actual.siguiente;
            }
            actual.siguiente = nuevoNodo;
        }

        public void imprimirLista() {
            Nodo actual = cabeza;
            while (actual != null) {
                System.out.print(actual.dato + " -> ");
                actual = actual.siguiente;
            }
            System.out.println("null");
        }
    }

    public static void main(String[] args) {
        System.out.println("Eliminar repetidos con dummy ");
        probarCasos(true);

        System.out.println("\nEliminar repetidos sin dummy ");
        probarCasos(false);
    }

    private static void probarCasos(boolean usarDummy) {
        int[][] casosPrueba = {
            {1, 1, 2, 3, 3, 4},
            {1, 1, 1},
            {1, 2, 2},
            {1, 2, 3},
            {5, 5, 6, 6},
            {}
        };

        for (int[] caso : casosPrueba) {
            ListaEnlazada lista = new ListaEnlazada();
            for (int val : caso) {
                lista.insertarFinal(val);
            }

            System.out.print("Entrada ");
            lista.imprimirLista();

            if (usarDummy) {
                lista.eliminarRepetidos();
            } else {
                lista.eliminarRepetidosSinDummy();
            }

            System.out.print("Salida ");
            lista.imprimirLista();
        }
    }
}
